--top 10 customers by total spend

WITH customer_spend AS (
  SELECT 
    CustomerID,
    ROUND(SUM(Quantity * UnitPrice), 2) AS total_spent
  FROM `enhanced-bonito-471805-s8.retail_dataset.online retail`
  WHERE Quantity > 0
  GROUP BY CustomerID
)
SELECT 
  CustomerID,
  total_spent,
  RANK() OVER (ORDER BY total_spent DESC) AS spend_rank
FROM customer_spend
ORDER BY total_spent DESC
LIMIT 10;
