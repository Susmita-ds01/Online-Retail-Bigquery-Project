--top 10 products by revenue

SELECT 
  Description AS product,
  ROUND(SUM(Quantity * UnitPrice), 2) AS total_revenue
FROM `enhanced-bonito-471805-s8.retail_dataset.online retail`
WHERE Quantity > 0 -- remove cancellations/returns
GROUP BY product
ORDER BY total_revenue DESC
LIMIT 10;
