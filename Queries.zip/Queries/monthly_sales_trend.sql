--Monthly Sales Trend

SELECT 
  EXTRACT(YEAR FROM InvoiceDate) AS year,
  EXTRACT(MONTH FROM InvoiceDate) AS month,
  ROUND(SUM(Quantity * UnitPrice), 2) AS monthly_revenue
FROM `enhanced-bonito-471805-s8.retail_dataset.online retail`
WHERE Quantity > 0
GROUP BY year, month
ORDER BY year, month;
